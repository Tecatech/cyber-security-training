default cards theme
